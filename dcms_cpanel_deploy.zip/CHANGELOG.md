# Changelog DCMS Gadgetmart

## [V2.5] - 2026-11-06
### Satu Gerbang Pengaturan: Integrasi Report Matrix dengan Data Karyawan & Bobot KPI
- **Integrasi Master Data Karyawan (Satu Gerbang Setting)**:
  - Kolom Report 1 (Daily Achievement Matrix) dan baris Report 2 (Achievement Omzet & GP vs Timegone serta Evaluasi Cross-Selling) kini sepenuhnya dinamis membaca dari master tabel `employees` di database.
  - Penambahan kolom `Target Omzet Bulanan (Rp)` pada data karyawan di menu Master Setting (`/settings/karyawan`), tabel karyawan, serta form modal tambah/edit sales.
  - Setiap perubahan karyawan aktif/nonaktif, penambahan admin sales baru, atau penyesuaian target individu di Master Setting langsung otomatis tercermin di Report Matrix Workspace Sosmed.
  - Algoritma pencocokan kode sales SAP Turnover yang cerdas: mencocokkan kode NIK resmi (`BJM.SOS.xxx`), alias (`SOSMED x`), maupun nama sales secara case-insensitive.
- **Konfigurasi Bobot KPI Matrix Dinamis**:
  - Tab *Bobot & Kriteria Penilaian* di `/settings/karyawan` kini dibagi menjadi 2 seksi transparan:
    1. **Bobot Rapor Matrix Sosmed**: Mengatur persentase bobot Omzet (default 35%), Gross Profit / GP (default 35%), dan Cross-Selling Gadget (default 30%).
    2. **Kriteria Kinerja Kualitatif**: Evaluasi layanan chat konsumen, respon time, etika, dan kepatuhan promo untuk monitoring harian manager sales.
  - Perhitungan persentase **% AKHIR (RAPOR)** dan status emoji performa (🖤/💔/☠️) di Report 2 kini dinamis mengikuti bobot yang ditentukan di Master Setting KPI.
  - Tag info standar pada tabel Report 2 otomatis menampilkan formula bobot yang sedang aktif secara realtime.
  - Endpoint baru `GET /api/workspace-settings` dan injeksi server-side `window.WORKSPACE_INITIAL_SETTINGS` untuk loading instan dengan 0ms latency.
- **Paket Deployment & Migrasi Database cPanel**:
  - Penambahan file migrasi `database/migrations/2026_11_06_100000_add_target_to_employees_table.php`.
  - Database dump `dcms_cpanel_core.sql` dan paket deployment `dcms_cpanel_deploy.zip` telah diperbarui sehingga pengguna dapat langsung redeploy ke cPanel atau menjalankan `/system/migrate?key=dcms2026`.

## [V2.4] - 2026-11-06
### Live Floating WhatsApp Widget, Relokasi Pusat Unggah Data & Super-Fast Bulk Deletion
- **Live Floating WhatsApp Widget di Seluruh Halaman (Global FAB)**:
  - Tombol aksi mengambang (*Floating Action Button*) hijau WhatsApp di pojok kanan bawah di seluruh halaman sistem (`layouts.live-chat-widget`).
  - Badge notifikasi berdenyut (*pulse animation*) dan suara *chime* lembut saat ada chat WhatsApp inbound baru yang belum dibalas.
  - Jendela ngambang (*floating window*) responsif untuk melihat percakapan masuk terbaru dan membalas chat secara ringkas secara instan via WAHA VPS API (`/api/watzap-send`).
  - Banner & tombol shortcut khusus *"Buka Modul Inbox FU Lengkap ↗"* untuk beralih ke Workspace Sosmed Tab 9 jika memerlukan respon kompleks, lampiran file/dokumen, atau pengisian Format Keep.
  - Auto-hide cerdas saat pengguna berada di Tab 9 (Inbox FU) di Workspace Sosmed agar tidak menumpuk.
- **Relokasi Menu Pusat Unggah Data ke Grup Setting**:
  - Memindahkan menu **Pusat Unggah Data** (`/imports`) dari grup *Customer & Outreach* ke dalam grup **Setting** di sidebar dengan badge **`SAP`**.
  - Penyesuaian highlight aktif `$isSettingActive` otomatis saat berada di halaman impor data.
- **Super-Fast Bulk Delete Pusat Unggah Data (Optimasi 98%)**:
  - Penghapusan riwayat impor batch besar (hingga 150.000+ baris transaksi) yang sebelumnya memakan waktu 2–4 menit kini selesai dalam **~2–3 detik**.
  - Menghapus pemanggilan PHP cursor `$predictor->rebuild()` yang berat pada saat aksi delete.
  - Menggunakan penghapusan bertahap (*chunked delete* per 25.000 baris) dengan *temporary foreign key check bypass* di MySQL.
  - Indikator status visual berupa spinner *"Menghapus..."* pada tombol konfirmasi.
- **Fix & Penyempurnaan Modul Omnichannel Inbox Follow-Up**:
  - Memperbaiki bug JavaScript `ReferenceError: mediaImg is not defined` di `client.js` sehingga pesan balasan teks langsung terkirim secara instan ke WhatsApp tujuan.
  - Dukungan pengiriman dan penerimaan file multimedia (foto/gambar dan dokumen PDF/Word/Excel) menggunakan format raw base64 langsung ke WAHA VPS (`/api/sendImage` & `/api/sendFile`).
  - Penanganan fallback cerdas pada *Quoted Reply* (kutipan pesan) di `WatzapService.php` agar pesan tetap terkirim walaupun ID pesan kutipan tidak tersimpan di memori WhatsApp.
  - Pembersihan formulir gateway cadangan (WatZap Cloud API) di halaman `/settings/watzap`, menyisakan fokus penuh pada WAHA VPS Primary dengan tombol shortcut langsung ke Inbox Follow-Up.
- **Rute Helper Migrasi Database cPanel Otomatis**:
  - Penambahan rute aman `/system/migrate?key=dcms2026` untuk memudahkan deployment di hosting cPanel yang tidak memiliki akses Terminal/SSH.
  - Otomatis menjalankan `php artisan migrate --force` dan `php artisan optimize:clear` langsung dari browser.
- **Paket Deployment Siap Pakai**:
  - Pembuatan file ZIP deployment otomatis `dcms-deploy-latest.zip` (37.45 MB) lengkap dengan folder `vendor/` dan aset Vite terkompilasi.

## [V2.3] - 2026-11-05
### Migrasi cPanel, Sinkronisasi Realtime Workspace Sosmed & Deteksi Periode Dinamis
- **Sinkronisasi Otomatis Pusat Unggah Data &rarr; Workspace Sosmed**:
  - File Cross-Selling dan Turnover yang diunggah melalui halaman Pusat Unggah Data (`/imports`) kini langsung disinkronkan secara realtime ke database `Setting` (`workspace_turnover_file_base64`, `workspace_croselling_file_base64`) dan file fisik publik (`public/workspace-sosmed/`).
  - Pengguna tidak perlu lagi melakukan re-upload manual di halaman Workspace Sosmed.
  - Peramban diubah agar selalu memprioritaskan mengambil file terbaru dari server API (`/api/get-excel?type=turnover`) sebelum menggunakan cache lokal IndexedDB.
- **Deteksi Periode Dinamis November 2026 & Resolusi Tanggal SAP**:
  - Engine Report Matrix kini otomatis mendeteksi periode bulan dan tahun aktif dari data transaksi turnover (mendukung 32.322+ baris transaksi November 2026).
  - Judul laporan (*Daily Achievement Sosmed*), jumlah hari (30 hari), dan target bulanan otomatis beradaptasi tanpa hardcoded Oktober.
  - Penanganan khusus *Inverted US-Locale Date* (`MM/DD/YYYY`) dari SAP untuk bulan November (`d.d === activeMonth`).
  - Dropdown filter Format Keep dan Audit AR kini membaca seluruh periode unik dari data Google Sheets secara dinamis dan otomatis memilih periode terbaru (`November-26 (Terbaru)`).
- **Fitur Hide / Collapse Sidebar Desktop (Open Workspace)**:
  - Sidebar desktop kini dapat di-minimize/sembunyikan secara halus (`margin-left: -18rem`, opacity 0, pointer-events none) agar area workspace report & tabel spreadsheet menjadi luas dan leluasa.
  - Ditambahkan tombol toggle collapse dedicated (`<<`) di bagian atas sidebar serta tombol hamburger di topbar yang selalu dapat diakses.
  - Ditambahkan keyboard shortcut global: `Ctrl+B` atau `Alt+S` untuk toggle sidebar instan.
  - Status collapse tersimpan di `localStorage` (`dcms_sidebar_collapsed`) dengan inline script pada `<head>` untuk mencegah efek loncat/flicker saat refresh.
- **Perbaikan Routing Controller & Stabilitas Engine**:
  - Pendaftaran rute `imports.destroy` dan `imports.destroy_turnover` pada `RouteCipher` untuk mencegah error routing controller saat menghapus data riwayat impor.
  - Proteksi `try/catch` pada rebuilding model repeat order predictor saat proses hapus impor agar tidak memicu timeout atau fatal error.
  - Memperbaiki deklarasi fungsi `handleOmniResolveClick` pada Omnichannel Inbox.
  - Isolasi inisialisasi awal aplikasi (`initSosmedApp`) dengan proteksi `try/catch` mandiri dan pengecekan aman `Array.isArray()` pada `renderArchiveGrid()`, sehingga kegagalan satu modul tidak menghentikan modul lainnya.
- **Migrasi Hosting cPanel & MySQL Localhost**:
  - Migrasi koneksi database dari Supabase PostgreSQL ke MySQL lokal dan cPanel (`dcms-sosmed.my.id`).
  - Penyediaan berkas dump database siap impor `dcms_cpanel_full.sql.zip` dan paket deploy siap pakai `dcms_cpanel_deploy.zip`.
  - Verifikasi menyeluruh: seluruh **148 automated tests** lulus 100% (green).

## [V2.2] - 2026-11-05
### Monitoring Kinerja Sales KPI & Manajemen Bobot
- **Modul Monitoring Kinerja Sales**:
  - Dashboard evaluasi KPI harian sales sosmed dengan pemisahan akses: Superadmin memiliki hak evaluasi & setting bobot, Admin view-only.
  - Filter cabang dan reset 24 jam untuk laporan broadcast.

## [V2.1] - 2026-11-04
### Fitur Baru & Peningkatan
- **Broadcast Delay & Proteksi Anti-Banned WhatsApp**:
  - Penambahan input konfigurasi delay per pengiriman pesan pada pembuatan broadcast WhatsApp.
  - Delay acak aman untuk meminimalkan risiko nomor terblokir / suspend oleh sistem spam filter WhatsApp.
  - Laporan status dan batch pengiriman broadcast per kampanye.
- **Integrasi WhatsApp Gateway WatZap (Broadcast & Inbox Follow-Up)**:
  - Pemisahan nomor sender antara WA Broadcast promosi dan nomor CS/Inbox Follow-Up.
  - Tombol pendaftaran otomatis Inbound Webhook (`/api/watzap-webhook`) langsung ke server WatZap via API.
  - Tombol pilihan cepat (*One-Click Selector*) nomor aktif yang terhubung di akun WatZap.
  - Normalisasi otomatis typo font antara huruf `l` (L kecil) dan `I` (i kapital) pada device number key.
  - Proteksi autofill browser password manager pada kolom API Key.
- **Penyempurnaan Antarmuka & UX**:
  - Perbaikan tuntas issue dropdown double / duplikat di seluruh modul aplikasi (Leads Customer, Prediksi RO, Laporan Broadcast, dll.).
  - Menggunakan native single `<select>` modern dengan chevron SVG custom dan transisi fokus yang halus.
  - Pembersihan header roomchat Workspace Sosmed (Inbox FU), menyisakan indikator status Online/Offline WhatsApp Gateway.

